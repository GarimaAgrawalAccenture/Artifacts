"""for abstract class modules"""
