# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['datax',
 'datax.utils.deployment_helper',
 'datax.utils.deployment_helper.abstract_class',
 'datax.utils.deployment_helper.converter',
 'datax.utils.deployment_helper.decorator',
 'datax.utils.deployment_helper.validation']

package_data = \
{'': ['*']}

install_requires = \
['pydantic>=1.10.2,<2.0.0', 'pyspark==3.2.1']

setup_kwargs = {
    'name': 'datax-utils-deployment-helper',
    'version': '0.5.0',
    'description': 'common lib for deployment-related',
    'long_description': '<a name="readme-top"></a>\n\n[![dev-status](https://github.com/datax-tmp/datax-utils-deployment-helper/workflows/dev/badge.svg)](https://github.com/datax-tmp/datax-utils-deployment-helper/actions)\n[![staging-status](https://github.com/datax-tmp/datax-utils-deployment-helper/workflows/staging/badge.svg)](https://github.com/datax-tmp/datax-utils-deployment-helper/actions)\n[![main-status](https://github.com/datax-tmp/datax-utils-deployment-helper/workflows/main/badge.svg)](https://github.com/datax-tmp/datax-utils-deployment-helper/actions)\n\n[![Interrogate](docs/content/asset/interrogate_badge.svg "interrogate")](https://interrogate.readthedocs.io/en/latest/#)\n\n<br />\n<div align="center">\n  <a href="https://github.com/datax-tmp/datax-utils-deployment-helper">\n    <img src="docs/content/asset/datax_logo.png" alt="Logo" width=60% height=60%>\n  </a>\n\n  <h3 align="center">DataX Deployment Utility</h3>\n\n  <p align="center">\n    We use this utility to deploy our products!\n    <br />\n    <a href="https://github.com/datax-tmp/datax-utils-deployment-helper"><strong>Explore the docs »</strong></a>\n    <br />\n    <br />\n    <a href="https://github.com/datax-tmp/datax-utils-deployment-helper">View Demo</a>\n    ·\n    <a href="https://github.com/datax-tmp/datax-utils-deployment-helper/issues">Report Bug</a>\n    ·\n    <a href="https://github.com/datax-tmp/datax-utils-deployment-helper/issues">Request Feature</a>\n  </p>\n</div>\n\n## About The Project\n\nThis library facilites applications deployment such as parsing parameterm, dynamic endpoint, abstract base class etc. It supports various kinds of pipeline that we have built, here at Data X.\n\nTo ensure development and deployment practices alignment among products, we have developed a way to standardize those processes using our in-house library.\n\n<p align="right">(<a href="#readme-top">back to top</a>)</p>\n\n## Getting Started\n\n.\n\n### Prerequisites\n\nPlease check `poetry.lock` to see package dependencies\n\n### Installation\n\n_Below is an example of how you can install this library._\n\n- with pip\n\n```sh\n$ pip intall datax-utils-deployment-helper\n```\n\n<p align="right">(<a href="#readme-top">back to top</a>)</p>\n\n## Usage\n\nPlease refer to the [Documentation](https://example.com)\n\n<p align="right">(<a href="#readme-top">back to top</a>)</p>\n\n## Contributing\n\nIf you have a suggestion that would make this better, please fork the repo and create a pull request. You can also simply open an issue with the tag "enhancement".\n\n1. Fork the Project\n2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)\n3. Commit your Changes (`git commit -m \'Add some AmazingFeature\'`)\n4. Push to the Branch (`git push origin feature/AmazingFeature`)\n5. Open a Pull Request\n\n<p align="right">(<a href="#readme-top">back to top</a>)</p>\n\n## License\n\nDistributed under the SCB DATA X License. See `LICENSE.txt` for more information.\n\n<p align="right">(<a href="#readme-top">back to top</a>)</p>\n\n## Contact\n\nAnalytics Product\n\n- Email - [analytics.product@data-x.ai](analytics.product@data-x.ai)\n\nDataHub Team\n\n- Email - [analytics.product.datahub@data-x.ai](analytics.product.datahub@data-x.ai)\n\nMachine Learning Engineering\n\n- Email - [analytics.product.mle@data-x.ai](analytics.product.mle@data-x.ai)\n\n<p align="right">(<a href="#readme-top">back to top</a>)</p>\n\n<!-- MARKDOWN LINKS & IMAGES -->\n<!-- https://www.markdownguide.org/basic-syntax/#reference-style-links -->\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
