# import: standard
import json
from dataclasses import asdict
from dataclasses import astuple
from dataclasses import dataclass
from dataclasses import field
from typing import List

# import: pyspark
from pyspark.sql.types import DataType
from pyspark.sql.types import StructType


@dataclass(frozen=True)
class SourceColumn:
    name: str  # column name
    data_type: DataType  # column data type
    nullable: bool  # column nullable constraint
    metadata: dict  # column metadata


@dataclass()
class SourceRegistry:

    schema_filepath: str = field(
        repr=False
    )  # path of JSON schema, config via a CLI call.
    expected_schema: dict = field(
        default=None, repr=False
    )  # deserialized schema from the loaded JSON schema
    expected_columns: List[
        SourceColumn
    ] = None  # list of SourceColumn parsed from the deserialized schema

    def __post_init__(self) -> None:

        self.expected_schema = self.__load_schema()
        self.expected_columns = self.__load_columns()

    def __load_schema(self) -> dict:

        with open(self.schema_filepath) as f:
            schema_json = json.load(f)
        schema = StructType.fromJson(schema_json)

        return schema

    def __load_columns(self) -> List[SourceColumn]:

        # expected_columns is a list contains information about columns defined in attributes of the SourceColumn dataclass
        expected_columns = [
            SourceColumn(field.name, field.dataType, field.nullable, field.metadata)
            for field in self.expected_schema
        ]

        return expected_columns


# For testing purpose
if __name__ == "__main__":
    sr = SourceRegistry("resources/people_schema.json")
    print("Expected Schema:\n\t", sr.expected_schema, "\n")
    print("Expected Columns:\n\t", sr.expected_columns, "\n")
    print("expected_columns as tuple:\n\t", astuple(sr), "\n")
    print("expected_columns as tuple:\n\t", asdict(sr), "\n")

    print("------" * 10)
    for column in sr.expected_columns:
        print(astuple(column))

    print("------" * 10)
    for column in sr.expected_columns:
        print(asdict(column))

    print()
    print("------" * 10)
    print(sr)
