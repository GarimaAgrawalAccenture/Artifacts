# import: standard
from dataclasses import dataclass
from dataclasses import field


@dataclass
class ColumnRegistry:

    method: str
    column_name: str
    version_major: int
    version_minor: int
    version_patch: int
    is_deprecate: bool
    created_date: int
    data_date_start: int
    data_date_end: int

    # method to create full column name
    def fullname(self) -> str:
        version = f"{self.version_major}_{self.version_minor}_{self.version_patch}"
        fullname = f"{self.column_name}_v_{version}"
        return fullname


# column version metadata
COLUMN_REGISTRY_DATA = [
    ColumnRegistry(
        "CrcardCardAggPipeline",
        "top_3_highest_spnd_total_txn_list",
        1,
        0,
        1,
        True,
        20220101,
        20220102,
        20220102,
    ),
    ColumnRegistry(
        "CrcardCardAggPipeline",
        "top_3_highest_spnd_total_txn_list",
        2,
        0,
        1,
        False,
        20220507,
        0,
        0,
    ),
    ColumnRegistry(
        "CrcardCardAggPipeline",
        "top_3_highest_spnd_total_txn_list",
        3,
        0,
        1,
        False,
        20220920,
        0,
        0,
    ),
]
