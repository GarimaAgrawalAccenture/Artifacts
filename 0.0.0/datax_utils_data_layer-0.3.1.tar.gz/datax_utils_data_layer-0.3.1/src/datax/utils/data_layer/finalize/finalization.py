# import: standard
from dataclasses import dataclass
from typing import Any
from typing import Callable
from typing import List

# import: pyspark
from pyspark.sql import DataFrame


class ColumnCheck:
    def __init__(self, registry_data: Any) -> None:
        self.COLUMN_REGISTRY_DATA = registry_data

    def output_column_check(self, df: DataFrame, x: List) -> DataFrame:

        actual_col = df.columns
        ref_col = [i.fullname() for i in x]

        diff_list = list(set(actual_col) ^ set(ref_col))
        if len(diff_list) != 0:
            diff_str = "\n".join(diff_list)
            raise LookupError(f"Column not matched \n{diff_str} ")

        return df

    def execute(self, df: DataFrame) -> DataFrame:

        return self.output_column_check(df, self.COLUMN_REGISTRY_DATA)
