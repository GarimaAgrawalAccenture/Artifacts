# import: standard
import json
from typing import List

# import: pyspark
from pyspark.sql.types import DataType
from pyspark.sql.types import StructType

# import: datax in-house
from datax.utils.deployment_helper.validation.common import check_path_endswith_dot_json

# import: external
from pydantic import BaseModel
from pydantic import validator


class SourceColumn(BaseModel):
    name: str
    data_type: DataType
    nullable: bool
    metadata: dict

    class Config:
        arbitrary_types_allowed = True


class SourceSchema(BaseModel):
    expected_schema: StructType

    class Config:
        arbitrary_types_allowed = True


class SourceSchemaFilePath(BaseModel):
    schema_filepath: str

    _check_path_endswith_dot_json = validator("schema_filepath", allow_reuse=True)(
        check_path_endswith_dot_json
    )


class SourceRegistry:
    def __init__(self, schema_filepath) -> None:

        self.schema_filepath = SourceSchemaFilePath(
            schema_filepath=schema_filepath
        ).schema_filepath
        self.expected_schema = self.__load_and_validate_schema(
            self.schema_filepath
        ).expected_schema
        self.expected_columns = self.__load_and_validate_columns(self.expected_schema)

    @staticmethod
    def __load_and_validate_schema(schema_filepath):
        with open(schema_filepath) as f:
            schema_json = json.load(f)
        schema = StructType.fromJson(schema_json)
        return SourceSchema(expected_schema=schema)

    @staticmethod
    def __load_and_validate_columns(expected_schema):
        expected_columns = [
            SourceColumn(
                name=field.name,
                data_type=field.dataType,
                nullable=field.nullable,
                metadata=field.metadata,
            )
            for field in expected_schema
        ]
        return expected_columns


# For testing purpose
if __name__ == "__main__":
    sr = SourceRegistry("resources/people_schema.json")
    print("Expected Schema:\n\t", sr.expected_schema, "\n")
    print("Expected Columns:\n\t", sr.expected_columns, "\n")
    print(sr)
