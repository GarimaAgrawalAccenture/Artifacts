# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['datax',
 'datax.utils.data_layer',
 'datax.utils.data_layer.column',
 'datax.utils.data_layer.dataclass',
 'datax.utils.data_layer.decorator',
 'datax.utils.data_layer.finalize',
 'datax.utils.data_layer.registry',
 'datax.utils.data_layer.table_schema',
 'datax.utils.data_layer.table_schema.customer360']

package_data = \
{'': ['*']}

install_requires = \
['pydantic>=1.10.2,<2.0.0', 'pyspark==3.2.1']

setup_kwargs = {
    'name': 'datax-utils-data-layer',
    'version': '0.3.1',
    'description': 'common lib for data layer',
    'long_description': '',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
