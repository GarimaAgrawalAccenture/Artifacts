"""for decorator modules"""
