# import: standard
import copy
import functools
from typing import Any
from typing import Callable
from typing import Dict
from typing import List
from typing import Tuple
from typing import TypeVar
from typing import cast

# import: pyspark
from pyspark.sql import DataFrame

# import: datax in-house
from datax.utils.data_layer.registry.source_registry import SourceRegistry

# func type annotation
F = TypeVar("F", bound=Callable[..., Any])


class InvalidStructFieldError(ValueError):
    """raise this when there's a DataFrame column error"""


def validate_schema(df: DataFrame, expected_schema: List) -> bool:
    missing_struct_fields = [x for x in df.schema if x not in expected_schema]
    error_message = f"{missing_struct_fields} field(s) are not included in the expected schema with {expected_schema} field(s)."
    if missing_struct_fields:
        raise InvalidStructFieldError(error_message)
    return True


def _access_dict_via_keys(input_dict: Dict, input_arg: Tuple) -> Any:
    """
    Use a tuple containing keys (input_arg) to access a dict (input_dict) and return value
    """
    this_dict = copy.deepcopy(input_dict)
    for i in range(len(input_arg)):
        this_dict = this_dict[input_arg[i]]
    return this_dict


def validate_data_source_schema(*data_source_arg: str) -> Callable[[F], F]:
    """
    Schema validator that use arguments to access schema path in self.data_source
    data_schema_path is a backdoor to pass in str of schema path
    """

    def decorator(func: F) -> F:
        """
        If input (data_source_arg) is a schema path ("this/is/example.json"),
        use it to validate df schema

        if pass dict keys pointed to schema path as input ("key_1", "key_2"),
        use self.data_source dict to get schema path and validate df schema
        """

        @functools.wraps(func)
        def wrapper(self: Any, *args: Any, **kwargs: Any) -> DataFrame:
            """
            Use dict keys to get a schema path from self.data_source
            """
            df = func(self, *args, **kwargs)
            ref_schema_path = _access_dict_via_keys(self.data_source, data_source_arg)
            schema = SourceRegistry(schema_filepath=ref_schema_path).expected_schema
            validate_schema(df, schema)
            return df

        @functools.wraps(func)
        def wrapper_direct(*args: Any, **kwargs: Any) -> DataFrame:
            """
            Use an input to validate df directly
            """
            df = func(*args, **kwargs)
            schema = SourceRegistry(schema_filepath=data_source_arg[0]).expected_schema
            validate_schema(df, schema)
            return df

        if len(data_source_arg) == 1 and ".json" in data_source_arg[0]:
            return cast(F, wrapper_direct)
        else:
            return cast(F, wrapper)

    return decorator
