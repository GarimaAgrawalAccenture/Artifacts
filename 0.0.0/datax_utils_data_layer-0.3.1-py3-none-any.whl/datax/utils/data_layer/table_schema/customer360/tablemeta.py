# import: standard
from typing import Dict
from typing import List
from typing import Optional

# import: datax in-house
from datax.utils.deployment_helper.validation.common import check_date_format

# import: external
from pydantic import BaseModel
from pydantic import validator


class VersionProperties(BaseModel):
    major: int
    is_deprecated: bool
    created_date: str
    data_date_start: str
    data_date_end: str
    originator: List[str]
    is_blended: bool
    type: str
    nullable: bool
    metadata: dict

    _check_date_format = validator(
        "created_date", "data_date_start", "data_date_end", allow_reuse=True
    )(check_date_format)


class PipelineDetails(BaseModel):
    base_column_name: str
    business_alias: str
    short_description: str
    long_description: str
    hashtag_keyword: List[str]
    generate_as: str
    product: str
    column_class: str
    status: Optional[str]
    series: Optional[str]
    value_representation: str
    update_frequency: str
    enrichment_type: str
    is_ml_based: bool
    version_property: List[VersionProperties]


class Registry(BaseModel):
    __root__: Dict[str, List[PipelineDetails]]


class Table(BaseModel):
    data_layer: str
    registry: Registry
